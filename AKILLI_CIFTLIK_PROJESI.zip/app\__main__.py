"""
Hayvancılık AI Sohbet Robotu - Modül olarak çalıştırma
python -m app komutu ile çalıştırılabilir.
"""

from run import main

if __name__ == "__main__":
    main()

