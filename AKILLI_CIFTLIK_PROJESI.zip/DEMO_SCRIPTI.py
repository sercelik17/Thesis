#!/usr/bin/env python3
"""
Akıllı Çiftlik Yönetim Sistemi - Demo Scripti
Bu script, sistemin tüm özelliklerini otomatik olarak test eder.
"""

import requests
import json
import time
import sys

# API Base URL
BASE_URL = "http://localhost:8000"

def print_header(title):
    """Başlık yazdır"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def print_step(step, description):
    """Adım yazdır"""
    print(f"\n[{step}] {description}")

def make_request(method, endpoint, data=None, headers=None):
    """HTTP isteği yap"""
    url = f"{BASE_URL}{endpoint}"
    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers)
        elif method.upper() == "POST":
            response = requests.post(url, json=data, headers=headers)
        elif method.upper() == "PUT":
            response = requests.put(url, json=data, headers=headers)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers)
        
        return response
    except requests.exceptions.ConnectionError:
        print("❌ HATA: Sunucuya bağlanılamıyor!")
        print("   Lütfen uygulamanın çalıştığından emin olun:")
        print("   python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload")
        sys.exit(1)

def demo_authentication():
    """Kimlik doğrulama demo"""
    print_header("KIMLIK DOGRULAMA DEMO")
    
    # Kullanıcı kaydı
    print_step("1", "Yeni kullanıcı kaydı")
    user_data = {
        "email": "demo@test.com",
        "username": "demo_user",
        "full_name": "Demo Kullanıcı",
        "password": "demo123"
    }
    
    response = make_request("POST", "/auth/register", user_data)
    if response.status_code == 200:
        print("✅ Kullanıcı başarıyla kaydedildi")
    else:
        print(f"⚠️  Kullanıcı zaten mevcut veya hata: {response.status_code}")
    
    # Giriş yapma
    print_step("2", "Giriş yapma")
    login_data = {
        "email": "demo@test.com",
        "password": "demo123"
    }
    
    response = make_request("POST", "/auth/login", login_data)
    if response.status_code == 200:
        token_data = response.json()
        token = token_data["access_token"]
        print("✅ Başarıyla giriş yapıldı")
        return token
    else:
        print(f"❌ Giriş başarısız: {response.status_code}")
        return None

def demo_farm_management(token):
    """Çiftlik yönetimi demo"""
    print_header("CIFTLIK YONETIMI DEMO")
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Çiftlik oluşturma
    print_step("1", "Yeni çiftlik oluşturma")
    farm_data = {
        "name": "Demo Çiftliği",
        "location": "Ankara, Türkiye",
        "farm_type": "cattle",
        "total_area": 100.0,
        "description": "Demo amaçlı çiftlik"
    }
    
    response = make_request("POST", "/farm/", farm_data, headers)
    if response.status_code == 200:
        farm = response.json()
        farm_id = farm["id"]
        print(f"✅ Çiftlik oluşturuldu: {farm['name']} (ID: {farm_id})")
    else:
        print(f"❌ Çiftlik oluşturulamadı: {response.status_code}")
        return None
    
    # Çiftlik listesi
    print_step("2", "Çiftlik listesi")
    response = make_request("GET", "/farm/", headers=headers)
    if response.status_code == 200:
        farms = response.json()
        print(f"✅ {len(farms)} çiftlik bulundu")
        for farm in farms:
            print(f"   - {farm['name']} ({farm['farm_type']})")
    
    return farm_id

def demo_animal_management(token, farm_id):
    """Hayvan yönetimi demo"""
    print_header("HAYVAN YONETIMI DEMO")
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Hayvan ekleme
    print_step("1", "Hayvan ekleme")
    animal_data = {
        "tag_number": "DEMO001",
        "name": "Bella",
        "species": "cattle",
        "breed": "Holstein",
        "gender": "female",
        "birth_date": "2020-03-15",
        "weight": 450.0,
        "status": "active",
        "notes": "Demo hayvanı"
    }
    
    response = make_request("POST", f"/farm/{farm_id}/animals", animal_data, headers)
    if response.status_code == 200:
        animal = response.json()
        animal_id = animal["id"]
        print(f"✅ Hayvan eklendi: {animal['name']} (Küpe: {animal['tag_number']})")
    else:
        print(f"❌ Hayvan eklenemedi: {response.status_code}")
        return None
    
    # Hayvan listesi
    print_step("2", "Hayvan listesi")
    response = make_request("GET", f"/farm/{farm_id}/animals", headers=headers)
    if response.status_code == 200:
        animals = response.json()
        print(f"✅ {len(animals)} hayvan bulundu")
        for animal in animals:
            print(f"   - {animal['name']} ({animal['species']}, {animal['breed']})")
    
    return animal_id

def demo_data_records(token, farm_id):
    """Veri kayıtları demo"""
    print_header("VERI KAYITLARI DEMO")
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Üretim kaydı
    print_step("1", "Üretim kaydı ekleme")
    production_data = {
        "animal_id": 1,
        "product_type": "milk",
        "quantity": 25.5,
        "unit": "liters",
        "date": "2024-01-15",
        "quality_grade": "A",
        "notes": "Günlük süt üretimi"
    }
    
    response = make_request("POST", f"/farm/{farm_id}/production-records", production_data, headers)
    if response.status_code == 200:
        print("✅ Üretim kaydı eklendi")
    else:
        print(f"⚠️  Üretim kaydı eklenemedi: {response.status_code}")
    
    # Finansal kayıt
    print_step("2", "Finansal kayıt ekleme")
    financial_data = {
        "transaction_type": "income",
        "amount": 1500.0,
        "description": "Süt satışı",
        "date": "2024-01-15",
        "category": "sales"
    }
    
    response = make_request("POST", f"/farm/{farm_id}/financial-records", financial_data, headers)
    if response.status_code == 200:
        print("✅ Finansal kayıt eklendi")
    else:
        print(f"⚠️  Finansal kayıt eklenemedi: {response.status_code}")

def demo_analytics(token, farm_id):
    """Analitik demo"""
    print_header("ANALITIK DEMO")
    
    headers = {"Authorization": f"Bearer {token}"}
    
    print_step("1", "Dashboard verileri")
    response = make_request("GET", f"/farm/{farm_id}/analytics/dashboard", headers=headers)
    if response.status_code == 200:
        analytics = response.json()
        print("✅ Dashboard verileri alındı:")
        print(f"   - Toplam hayvan: {analytics.get('total_animals', 'N/A')}")
        print(f"   - Aylık üretim: {analytics.get('monthly_production', 'N/A')}")
        print(f"   - Toplam gelir: {analytics.get('total_income', 'N/A')}")
    else:
        print(f"⚠️  Dashboard verileri alınamadı: {response.status_code}")

def demo_ai_chat(token, farm_id):
    """AI Chat demo"""
    print_header("AI ASISTAN DEMO")
    
    headers = {"Authorization": f"Bearer {token}"}
    
    # Test soruları
    questions = [
        "Çiftliğimde kaç hayvan var?",
        "Bu ay ne kadar süt üretimi yaptım?",
        "Hangi hayvanların aşı zamanı geldi?",
        "Çiftliğimin karlılık durumu nasıl?"
    ]
    
    for i, question in enumerate(questions, 1):
        print_step(f"{i}", f"AI Sorusu: '{question}'")
        
        chat_data = {
            "message": question,
            "context": "farm_analysis"
        }
        
        response = make_request("POST", f"/farm/{farm_id}/chat", chat_data, headers)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ AI Yanıtı: {result.get('response', 'Yanıt alınamadı')[:100]}...")
        else:
            print(f"⚠️  AI yanıtı alınamadı: {response.status_code}")
        
        time.sleep(1)  # API rate limiting için

def demo_security():
    """Güvenlik demo"""
    print_header("GUVENLIK DEMO")
    
    print_step("1", "Yetkisiz erişim testi")
    response = make_request("GET", "/farm/")
    if response.status_code == 401:
        print("✅ Yetkisiz erişim engellendi")
    else:
        print(f"⚠️  Güvenlik açığı: {response.status_code}")
    
    print_step("2", "Geçersiz token testi")
    headers = {"Authorization": "Bearer invalid_token"}
    response = make_request("GET", "/farm/", headers=headers)
    if response.status_code == 401:
        print("✅ Geçersiz token engellendi")
    else:
        print(f"⚠️  Token doğrulama hatası: {response.status_code}")

def main():
    """Ana demo fonksiyonu"""
    print_header("AKILLI CIFTLIK YONETIM SISTEMI - DEMO")
    print("Bu script, sistemin tüm özelliklerini test eder.")
    print("Uygulamanın çalıştığından emin olun!")
    print()
    
    try:
        # 1. Kimlik doğrulama
        token = demo_authentication()
        if not token:
            print("❌ Demo başarısız: Kimlik doğrulama hatası")
            return
        
        # 2. Çiftlik yönetimi
        farm_id = demo_farm_management(token)
        if not farm_id:
            print("❌ Demo başarısız: Çiftlik yönetimi hatası")
            return
        
        # 3. Hayvan yönetimi
        animal_id = demo_animal_management(token, farm_id)
        
        # 4. Veri kayıtları
        demo_data_records(token, farm_id)
        
        # 5. Analitik
        demo_analytics(token, farm_id)
        
        # 6. AI Chat
        demo_ai_chat(token, farm_id)
        
        # 7. Güvenlik
        demo_security()
        
        print_header("DEMO TAMAMLANDI!")
        print("✅ Tüm özellikler başarıyla test edildi!")
        print()
        print("Web arayüzünü görmek için:")
        print("http://localhost:8000")
        print()
        print("API dokümantasyonu için:")
        print("http://localhost:8000/docs")
        
    except KeyboardInterrupt:
        print("\n❌ Demo kullanıcı tarafından durduruldu")
    except Exception as e:
        print(f"\n❌ Demo hatası: {e}")

if __name__ == "__main__":
    main()
