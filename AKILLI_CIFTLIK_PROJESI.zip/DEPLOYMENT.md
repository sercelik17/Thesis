# 🚀 Hayvancılık AI Sohbet Robotu - Deployment Rehberi

## 🌐 Canlı Yayınlama Seçenekleri

### 1. Railway ile Deployment (Önerilen)

#### Adım 1: GitHub'a Yükleme
```bash
# Git repository oluştur
git init
git add .
git commit -m "Initial commit - Hayvancılık AI Sohbet Robotu"
git branch -M main
git remote add origin https://github.com/yourusername/livestock-ai-chatbot.git
git push -u origin main
```

#### Adım 2: Railway'e Deploy
1. [Railway.app](https://railway.app) adresine git
2. GitHub ile giriş yap
3. "New Project" → "Deploy from GitHub repo"
4. Repository'yi seç
5. Otomatik deploy başlar
6. URL: `https://your-project.railway.app`

### 2. Render ile Deployment

#### Adım 1: Render'e Deploy
1. [Render.com](https://render.com) adresine git
2. GitHub ile giriş yap
3. "New" → "Web Service"
4. Repository'yi seç
5. Build Command: `pip install -r requirements_simple.txt`
6. Start Command: `python simple_app.py`
7. URL: `https://your-project.onrender.com`

### 3. Heroku ile Deployment

#### Adım 1: Heroku CLI Kurulumu
```bash
# Heroku CLI indir ve kur
# https://devcenter.heroku.com/articles/heroku-cli
```

#### Adım 2: Deploy
```bash
# Heroku'ya giriş
heroku login

# Uygulama oluştur
heroku create your-livestock-ai

# Deploy et
git push heroku main

# URL: https://your-livestock-ai.herokuapp.com
```

## 🔧 Domain Bağlama (haytek.org.tr)

### Railway ile Custom Domain
1. Railway dashboard'da projeyi seç
2. "Settings" → "Domains"
3. "Custom Domain" ekle
4. `chat.haytek.org.tr` veya `ai.haytek.org.tr` ekle
5. DNS ayarlarını yap

### DNS Ayarları
```
Type: CNAME
Name: chat (veya ai)
Value: your-project.railway.app
TTL: 300
```

## 📊 Performans Optimizasyonu

### Production Ayarları
```python
# simple_app.py'de
DEBUG = False
HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", 8000))
```

### Environment Variables
```env
# Railway/Render/Heroku'da ayarla
DEBUG=False
HOST=0.0.0.0
PORT=8000
```

## 🔒 Güvenlik

### SSL Sertifikası
- Railway, Render, Heroku otomatik SSL sağlar
- Custom domain için Let's Encrypt kullan

### API Rate Limiting
```python
# Gelecekte eklenebilir
from slowapi import Limiter
limiter = Limiter(key_func=get_remote_address)
```

## 📈 Monitoring

### Health Check
- Endpoint: `/health`
- Railway/Render otomatik health check yapar

### Logs
- Railway: Dashboard'da logs görüntüle
- Render: Logs sekmesinde görüntüle
- Heroku: `heroku logs --tail`

## 🎯 Önerilen Deployment Sırası

1. **Railway** (En kolay, hızlı)
2. **Render** (Güvenilir, ücretsiz)
3. **Heroku** (Popüler, özellik zengin)
4. **VPS** (Tam kontrol, maliyetli)

## 📞 Destek

Deployment sırasında sorun yaşarsanız:
1. Logs'ları kontrol edin
2. Environment variables'ları kontrol edin
3. Port ayarlarını kontrol edin
4. Requirements.txt dosyasını kontrol edin

---

**Başarılı deployment! 🎉**

Projeniz canlı yayında olacak ve haytek.org.tr domain'i ile erişilebilir olacak!

