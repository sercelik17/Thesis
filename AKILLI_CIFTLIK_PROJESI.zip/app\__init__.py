# Hayvancılık Sektöründe Yapay Zeka Destekli Sohbet Robotu
# LangChain ve RAG Teknolojileriyle Geliştirilmiş

