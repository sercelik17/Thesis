# HOCA ICIN OZEL NOTLAR 
 
## Proje Hakkinda 
Bu proje, yapay zeka destekli akilli ciftlik yonetim sistemidir. 
 
## Hizli Baslangic 
1. KURULUM_SCRIPTI.bat dosyasini calistirin 
2. python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload 
3. http://localhost:8000 adresini acin 
4. admin@livestock.com / admin123 ile giris yapin 
 
## Demo 
python DEMO_SCRIPTI.py 
 
## Tez Dokumanlari 
TEZ/ klasorunde markdown formatinda hazirlanmistir. 
 
## Canli Sistem 
https://haytek.org.tr 
 
## Iletisim 
[Ogrenci Adi] - [E-posta] 
